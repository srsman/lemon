void printUsage(char *command);
int getArgument(int argc, char *argv[],  char** filePrefix);
int getArgumentsMultiChannel(int argc, char *argv[], char *filePrefix[]);
